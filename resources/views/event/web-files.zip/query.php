<?php

// configure

$emailfrom = $_POST['email']; 
$headers1 = "MIME-Version: 1.0" . "\r\n";
$headers1 .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
$headers1 .= "From: ".$emailfrom;

$sendTo = 'contact@admitoffer.com';

$subject = 'New message from CANADA & UK MEET form';

$fields = array('name' => 'Name', 'phone' => 'Phone', 'email' => 'Email'); // array variable name => Text to appear in email

$okMessage = 'Contact form successfully submitted. Thank you, We will get back to you soon!';

$errorMessage = 'There was an error while submitting the form. Please try again later';

$captcha=$_POST['g-recaptcha-response'];

$secretKey = '6LdqDcIUAAAAACwZsE9V0qm-d3JRFfxV3557G6_W';

// let's do the sending

try

{

	$ch = curl_init();

curl_setopt_array($ch, [

    CURLOPT_URL => 'https://www.google.com/recaptcha/api/siteverify',

    CURLOPT_POST => true,

    CURLOPT_POSTFIELDS => [

        'secret' => $secretKey,

        'response' => $captcha,

        'remoteip' => $_SERVER['REMOTE_ADDR']

    ],

    CURLOPT_RETURNTRANSFER => true

]);

$output = curl_exec($ch);

curl_close($ch);

$json = json_decode($output);

		if (isset($json->success) && $json->success) {

    $emailText = "You have new message from contact form <br> ============================= <br>";
    foreach ($_POST as $key => $value) {
        if (isset($fields[$key])) {
            $emailText .= "$fields[$key]: $value<br>";
        }
    }
	
	
    mail($sendTo, $subject, $emailText, $headers1);

    $responseArray = array('type' => 'success', 'message' => $okMessage);

}
}

catch (\Exception $e)

{

    $responseArray = array('type' => 'danger', 'message' => $errorMessage);

}

if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {

    $encoded = json_encode($responseArray);

    header('Content-Type: application/json');

    echo $encoded;

}

else {

    echo $responseArray['message'];

}