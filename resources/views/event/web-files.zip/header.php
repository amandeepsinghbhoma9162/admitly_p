<div class="wrapper">

<header id="header">
    <div class="container">

      <div id="logo" class="cy_logo_box">
         <a href="index.php"><img src="img/logo.png" alt="" title="" /></a>
      </div>

      <?php /*
      <nav id="nav-menu-container" class="main-nav float-right">
        <ul class="nav-menu">
          <li><a href="index.php#home1" id="">Home</a></li>
          <li><a href="index.php#zoom" id="">Book Counseling</a></li>          
          <li><a href="index.php#aboutus" id="">About Us</a></li>        
          <li><a href="index.php#team" id="">Meet the Team</a></li>                
        </ul>
      </nav>
      */ ?>

    </div>
  </header>
 </div>