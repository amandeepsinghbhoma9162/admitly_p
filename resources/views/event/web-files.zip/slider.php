<section id="intro">

    <div class="intro-container">
      <div id="introCarousel" class="carousel  slide carousel-slide" data-ride="carousel">

       <!-- <ol class="carousel-indicators"></ol>-->
        <div class="carousel-inner" role="listbox">
          <div class="carousel-item active">
            <div class="carousel-background"><img src="img/canada-uk.jpg" alt=""></div>
            <div class="container">
              <div class="carousel-content">
              <div class="row">
                  
                  <div class="col-md-10 offset-md-1 text-center">
                    
                    
                    <div class="wow animated fadeInUp" data-wow-delay="0.5s"><h2>CANADA <span>&</span> UK</h2></div>
                    
                    <div class="wow animated fadeInUp" data-wow-delay="0.7s"><h3>Agent Meet</h3></div>
                    <div class="wow animated fadeInUp" data-wow-delay="0.9s">
                    	<h5>Networking | Dinner | Cocktails</h5>
                    </div>
                    
                    
                    
                    <div class="btns wow animated fadeInUp">
                      <a href="#register-now" class="btn2 wow animated fadeInUp" data-wow-delay="1s">Register Now</a>
                    </div>
                    
                   </div>
                   
                   
                   
               </div>
               </div>
               
            </div>
          </div>

          
          
          

        </div>

        <?php /*?><a class="carousel-control-prev" href="#introCarousel" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon ion-chevron-left" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>

        <a class="carousel-control-next" href="#introCarousel" role="button" data-slide="next">
          <span class="carousel-control-next-icon ion-chevron-right" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a><?php */?>

      </div>
    </div>
  </section>